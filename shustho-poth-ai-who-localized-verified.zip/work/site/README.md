# Shustho Poth AI
## From local words to the next safe step.

An offline-first, Bangla/Banglish-first Small AI prototype for frontline health workers.

### Core workflow
**Everyday patient language → small local classifier → structured information → uncertainty/missing fields → human decision → referral/follow-up record → offline save → later sync.**

### What is actually AI?
A tiny Naive Bayes classifier runs locally in the browser. It classifies a narrow set of intents from unstructured Bangla/Banglish text. Transparent rule-based extraction identifies fields such as duration, age, reduced intake, breathing report, financial barrier, travel barrier and connectivity.

It does **not** diagnose, prescribe treatment, or make the final referral decision.

### Dataset
`data/local_language_dataset.csv` contains **105 synthetic training examples and 49 held-out synthetic test examples** across seven narrow intents. It includes Bangla and Banglish examples.

Held-out result: **98.0% accuracy; 97.9% macro-F1 (48/49 correct)**. One connectivity example was misclassified as a financial barrier and is retained as an explicit error. These metrics are prototype evaluation only and are **not clinical validation**.

### Bangladesh facility layer
`data/facilities_dghs_sample.json` contains six sample records from the public DGHS Facility Registry, using fields visible in that registry. The current public registry reports facility ID, English/Bangla name, type, agency, administrative areas and active/private fields. The sample is not a complete database and the prototype does not infer distance, opening hours, bed availability or clinical capacity. Verify live information before deployment.

### Mobile money / affordability
The prototype captures a reported financial access barrier and shows mobile money, cash and verified assistance as possible workflow routes. It does not initiate payments or claim insurance eligibility.

### Why AI instead of a form?
A static form can store fields and an SMS workflow can transmit fixed fields. The narrow AI task here is converting messy local-language descriptions into structured information and flagging uncertainty without requiring the worker to manually map every phrase to a field.

### Responsible AI
- Human health worker makes the final decision.
- Missing information is surfaced.
- Low confidence can trigger review.
- No autonomous diagnosis or treatment.
- Synthetic cases are clearly labeled.
- Facility data is a non-live sample.
- Payment/assistance options must be verified before deployment.

### Run
Open `index.html` in a browser. The core classifier and workflow run client-side.

### Source
DGHS Facility Registry: https://hrm.dghs.gov.bd/public/facility-registry

This is a hackathon prototype, not a clinical device or validated medical decision-support system.
## WHO Bangladesh health-priority evidence

`data/who_bangladesh_health_priorities.json` contains 351 source observations across 15 WHO indicators extracted from the user-supplied `050_Bangladesh.zip`. The selected series cover tuberculosis, malaria, road-traffic mortality, maternal mortality, under-five and neonatal mortality, premature NCD mortality, hypertension, stunting, wasting, air pollution, unsafe WASH, and physician, nursing/midwifery, and pharmaceutical personnel density. `data/who_health_priority_mapping.json` documents whether these priorities correspond to an existing prototype intent; all disease and population indicators are context-only and do not enter classification.

Years below are the observed years in the supplied CSV files, not a claim that every year has a value for every sex or subgroup. `source_row` in the JSON is the row number in its source dataset CSV. Values and lower/upper bounds are retained without recalculation.

| WHO indicator | Indicator code(s) | Observed year span | Source rows |
|---|---|---:|---:|
| Probability of premature mortality from NCDs | `NCDMORT3070` | 2000–2020 | 22 |
| Density of physicians (per 10 000 population) | `HWF_0001` | 2001–2023 | 22 |
| Under-five mortality rate (per 1000 live births) | `MDG_0000000007` | 1960–2023 | 37 |
| Malaria incidence (per 1000 population at risk) | `MALARIA_EST_INCIDENCE` | 2000–2024 | 25 |
| Density of pharmaceutical personnel  (per 10 000 population) | `HWF_0014` | 2002–2023 | 13 |
| Density of nursing and midwifery personnel (per 10 000 population) | `HWF_0006` | 2003–2023 | 20 |
| Prevalence of stunting in children under 5 (%) | `NUTSTUNTINGPREV` | 2000–2023 | 20 |
| Age-standardized prevalence of hypertension among adults aged 30 to 79 years (%) | `NCD_HYP_PREVALENCE_A` | 1990–2019 | 22 |
| Neonatal mortality rate (per 1000 live births) | `WHOSIS_000003` | 1952–2023 | 29 |
| Maternal mortality ratio (per 100 000 live births) | `MDG_0000000026                                                     SDG Indicator 3.1.1` | 1985–2020 | 26 |
| Tuberculosis incidence (per 100 000 population) | `MDG_0000000020                                                     20                                                     SDG Indicator 3.3.2                                                     1426` | 2000–2023 | 24 |
| Road traffic mortality rate (per 100 000 population) | `RS_198` | 2021–2021 | 1 |
| Age-standardized mortality rate attributed to household and ambient air pollution  (per 100 000 population) | `SDGAIRBODA` | 2010–2019 | 26 |
| Mortality rate attributed to exposure to unsafe WASH services (per 100 000 population) | `SDGWSHBOD` | 2019–2019 | 3 |
| Prevalence of wasting in children under 5 (%) | `NUTRITION_WH_2` | 1991–2022 | 61 |

The supplied package did **not** include the separate leading-causes-of-death dataset, so no cause names or estimates are asserted here. The WHO country overview says Bangladesh death-registration data are unavailable or unusable for cause-of-death analysis because of data-quality concerns; its modelled cause estimates should be interpreted cautiously and are intended for priority-setting rather than policy evaluation or cross-country comparison ([WHO Bangladesh country data](https://data.who.int/countries/050), accessed 4 October 2026).

Two source caveats are retained rather than silently resolved: some CSV year ranges extend beyond their associated metadata temporal-coverage statements, and the wasting CSV contains multiple rows for the same year/sex without sufficient included dimensions to select one. All rows remain in the JSON, with `source_row` for traceability. The TB dataset also repeats the same 221 estimate and 161–291 bounds for every supplied year from 2000–2023; this source anomaly is preserved as published, not interpreted as a verified trend.

WHO indicator dataset-specific license files in the package state **CC BY 4.0**; see each referenced `license_terms` file path in the JSON provenance. Attribution: World Health Organization (WHO), Bangladesh indicator datasets, package supplied 4 October 2026. WHO does not endorse this application; do not use the WHO name or emblem to imply endorsement. No WHO API is called at runtime; the evidence file is static and local. The UI may be unable to fetch local JSON when `index.html` is opened using `file://` in some browsers, but classification does not depend on that fetch.

These indicators only provide population-level context. They do not diagnose an individual, validate the classifier, provide individualized risk, prescribe treatment, or determine referral. The human health worker remains the final decision-maker.
